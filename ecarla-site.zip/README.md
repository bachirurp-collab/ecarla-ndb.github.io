# ECARLA — Site officiel

Site web de l’association d’aéronautique ECARLA (Nouadhibou, Mauritanie)

## Structure
- HTML statique (GitHub Pages)
- CSS simple et responsive
- Formulaire via Formspree

## Déploiement
1. Modifier les fichiers locaux
2. git add . && git commit -m "Mise à jour du site" && git push
3. Vérifier sur https://ecarla-ndb.github.io